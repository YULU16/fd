package level;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;

import javax.swing.ImageIcon;
import javax.swing.JFrame;


public class yellow extends JFrame  {
	int x;
	int y;
Image image;
ImageIcon icon;
	public yellow(int x, int y) {
	this.x=x;
	this.y=y;
	
	icon=new ImageIcon("ye.jpg");
		image=icon.getImage();
	
	}


	
	
	
public void draw(Graphics g) {
	g.drawImage(image,x,y,100,80,this);
	
}






   
   
	
	
}
