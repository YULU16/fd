package level;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;

import javax.swing.ImageIcon;
import javax.swing.JFrame;


public class mgold extends JFrame  {
	int x;
	int y;
Image image;
ImageIcon icon;
public int price= 200;
	public mgold(int x, int y) {
	this.x=x;
	this.y=y;
	
		icon=new ImageIcon("mg.jpg");
		image=icon.getImage();
	
	}


	
	
	
public void draw(Graphics g) {
	g.drawImage(image,x,y,90,70,this);
}
}