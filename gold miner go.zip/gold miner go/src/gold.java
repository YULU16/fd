
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;

import javax.swing.ImageIcon;
import javax.swing.JFrame;


public class gold extends JFrame  {
	int x;
	int y;
	int price=500;
Image image;
ImageIcon icon;
	public gold(int x, int y) {
	this.x=x;
	this.y=y;
	
	icon=new ImageIcon("bg.jpg");
		image=icon.getImage();
	
	}


	
	
	
public void draw(Graphics g) {
	g.drawImage(image,x,y,150,120,this);
	
}






   
   
	
	
}
