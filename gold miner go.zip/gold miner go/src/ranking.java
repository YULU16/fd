import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;




public class ranking extends JFrame{
	JButton b1=new JButton();
	JButton b2=new JButton();
	JButton b3=new JButton();

	JButton b4=new JButton();
	JButton b5=new JButton();
	JButton b6=new JButton();
	JButton b7=new JButton();
	JButton b8=new JButton();
	JButton b9=new JButton();
	JButton b10=new JButton();
	JButton b11=new JButton();
	JButton b12=new JButton();
	JButton u=new JButton("Close");
	
	
	
	public ranking(){
super("ranking");
setUndecorated(true);
this.setSize(1200,800);
this.setLocationRelativeTo(null);//ʹ������ʾ����Ļ����
String path = "15.jpg";  //·��
ImageIcon background = new ImageIcon(path);//����ͼƬ  
JLabel label = new JLabel(background);//ͼƬ���ӵ���ǩ��
label.setBounds(0, 0, this.getWidth(), this.getHeight());  


// �����ݴ���ת��ΪJPanel���������÷���setOpaque()��ʹ���ݴ���͸��  
JPanel imagePanel = (JPanel) this.getContentPane();  
imagePanel.setLayout(new GridLayout(6,2));
imagePanel.setOpaque(false);  

// �ѱ���ͼƬ���ӵ��ֲ㴰�����ײ���Ϊ����  
this.getLayeredPane().add(label, new Integer(Integer.MIN_VALUE));  

//���ÿɼ�  


b1= new JButton("Players");
b2= new JButton("Ranking");
b3= new JButton("A");
b4=new JButton("1");
b5=new JButton("B");
b6=new JButton("2");
b7=new JButton("C");
b8=new JButton("4");;
b9=new JButton("D");
b10=new JButton("5");
b11=new JButton("E");
b12=new JButton("6");




b12.addActionListener(new B());


b1.setBackground(Color.YELLOW);
b1.setOpaque(false);  
b2.setBackground(Color.YELLOW);
b2.setOpaque(false);  
b3.setBackground(Color.YELLOW);
b3.setOpaque(false);  
b4.setBackground(Color.YELLOW);
b4.setOpaque(false);  
b5.setBackground(Color.YELLOW);
b5.setOpaque(false);  
b6.setBackground(Color.YELLOW);
b6.setOpaque(false);  
b7.setBackground(Color.YELLOW);
b7.setOpaque(false);  
b8.setBackground(Color.YELLOW);
b8.setOpaque(false);  
b9.setBackground(Color.YELLOW);
b9.setOpaque(false);  
b10.setBackground(Color.YELLOW);
b10.setOpaque(false);  
b11.setBackground(Color.YELLOW);
b11.setOpaque(false);  
b12.setBackground(Color.YELLOW);
b12.setOpaque(false);  

b1.setFont(new Font("Aharoni", Font.BOLD, 80));
b2.setFont(new Font("Aharoni", Font.BOLD, 80));

b3.setFont(new Font("Aharoni", Font.BOLD, 80));
b4.setFont(new Font("Aharoni", Font.BOLD, 80));
b5.setFont(new Font("Aharoni", Font.BOLD, 80));
b6.setFont(new Font("Aharoni", Font.BOLD, 80));
b7.setFont(new Font("Aharoni", Font.BOLD, 80));
b8.setFont(new Font("Aharoni", Font.BOLD, 80));
b9.setFont(new Font("Aharoni", Font.BOLD, 80));
b10.setFont(new Font("Aharoni", Font.BOLD,80));
b11.setFont(new Font("Aharoni", Font.BOLD, 80));
b12.setFont(new Font("Aharoni", Font.BOLD, 80));





imagePanel.add(b1);
imagePanel.add(b2);
imagePanel.add(b3);
imagePanel.add(b4);
imagePanel.add(b5);
imagePanel.add(b6);
imagePanel.add(b7);
imagePanel.add(b8);
imagePanel.add(b9);
imagePanel.add(b10);
imagePanel.add(b11);
imagePanel.add(b12);
this.setVisible(true);

	}

	
public static void main(String args[]){
	new ranking();
}
public class B implements ActionListener{
	
	public B(){
		
	}
protected void dis (ActionEvent e){
	dispose();
	new start();
}

	@Override
	public void actionPerformed(ActionEvent e) {
		dis(e);// TODO Auto-generated method stub
		
	}
	
}
}
