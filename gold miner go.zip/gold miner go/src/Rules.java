import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;








public class Rules extends JFrame  {
	JLabel labOne1;
	JPanel p1;
	 JButton button1;
	JTextArea t;
	boolean a=true;
	public Rules(){
		
		super("Rules");
		 this.setSize(1200,800);
		 this.setLocationRelativeTo(null);//ʹ������ʾ����Ļ����
	
		setUndecorated(true);

        String path = "aa.jpg";  
        ImageIcon background = new ImageIcon(path);  
        JLabel label = new JLabel(background);
        label.setBounds(400, 0, 800,900);  
		
        p1 = (JPanel) this.getContentPane();  
        p1.setLayout(null);
       p1.setOpaque(false);  
        
        this.getLayeredPane().add(label, new Integer(Integer.MIN_VALUE));  
        
		t=new JTextArea ("1.Player use the hook to  grasp the gold\n\n" +
				"2.When players grasp the  gold, the mark will       increase\n\n" +
				"3.When you get enough     marks, you can come to    the next level\n");
	
		t.setLineWrap(true);
		t.setBounds(20,120,450,350);
		t.setFont(new Font("����", Font.BOLD, 30));
		t.setOpaque(false);
		labOne1=new JLabel("The rules");
		labOne1.setBounds(80,50,1000,50);
		labOne1.setFont(new Font("����", Font.BOLD, 60));

		
		Container contentPane=this.getContentPane();
		button1 = new JButton("Details");
		button1.setBounds(100,500,200,30);
		button1.setFont(new Font("Aharoni", Font.BOLD, 30));
		button1.setBackground(Color.YELLOW);
		 button1.setOpaque(false);  
		

		p1.setLayout(null);
		
		p1.add(labOne1);
		p1.add(t);
		p1.add(button1);
		button1.addActionListener(new B());
		
     
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		
	
	}
	
	
	public static void main(String agrs[]){
		new Rules();
	}
		
    class B implements ActionListener{
    		details d = new details();
		@Override
		public void actionPerformed(ActionEvent e) {
			if(a){
				d.setVisible(true);
				a=false;
				button1.setText("Close the details");
			}
			else{
				d.setVisible(false);
				a=true;
				button1.setText(" Details");
			}
				}
			
		}
		
	
		}

