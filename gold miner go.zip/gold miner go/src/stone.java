
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;

import javax.swing.ImageIcon;
import javax.swing.JFrame;


public class stone extends JFrame  {
	int x;
	int y;
Image image;
ImageIcon icon;
public int price=20;;
	public stone(int x, int y) {
	this.x=x;
	this.y=y;
	
		icon=new ImageIcon("s.jpg");
		image=icon.getImage();
	
	}


	
	
	
public void draw(Graphics g) {
	g.drawImage(image,x,y,100,80,this);
	
}
}